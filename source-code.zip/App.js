import React from "react";
import {useState} from "react";

const allBrands = [
  {id:"1",brandName:"addidas"},
  {id:"2",brandName:"puma"},
  {id:"3",brandName:"bearhouse"},
  {id:"4",brandName:"niki"},
  {id:"5",brandName:"sparx"},
  {id:"6",brandName:"redtap"},
]

function App() {
  const [brands,setBrands] = useState(allBrands);
  const [selected,setSelected] = useState([]);
  const onSearch = (e)=>{
    const value = e.target.value
    const filtered = value?.length > 0 ? brands.filter(brand => brand.brandName.includes(value.toLowerCase())) : allBrands;
    setBrands(filtered)
  }
  const onAdd = (id) =>{
    const selectedItems = allBrands.find(item => item.id == id);
      
    setSelected([...selected,selectedItems]);
  }
  const onRemove =(id)=>{
    const fil = selected.filter(item => item.id !== id);
    setSelected(fil);
  }
  return(
    <>
    <input onChange={onSearch} placeholder ='Enter the brand' />
      <ul>
      {
        brands.map(brand => <li key={brand.id}>{brand.brandName}</li>)
      }
      </ul>

      <div>
      <p>Add  To Cart</p>
        {
          allBrands.map(brand => <div>
          <p>{brand.brandName}</p>
            <button onClick={() => onAdd(brand.id)}>Add</button>
          </div>)
        }
      </div>
      <div>
      <p>Your Cart</p>
        {
          selected && selected.map(brand => <p>{brand.brandName}        - <button onClick={()=>onRemove(brand.id)} >Remove</button></p>)
        }
      </div>
    </>
  );
}
export default App;

